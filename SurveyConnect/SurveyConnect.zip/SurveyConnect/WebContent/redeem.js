/**
 * 
 */

function renderRedeem() {

`<table id="redeem">
    <thead>
    	<tr>
    		<th>Starbucks </th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$5</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$10</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$15</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$20</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$25</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$30</th>
      </tr>
    </thead>
    <tbody>
    	<td style="text-align: center; vertical-align: middle;">
    		<figure class="image is-128x128 is-text-centered">
 					<img src="https://www.stickpng.com/assets/images/58428cc1a6515b1e0ad75ab1.png">
				</figure>
    	</td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
     
    </tbody>
  </table>

  <table id="redeem">
    <thead>
    	<tr>
    		<th> VISA </th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$5</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$10</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$15</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$20</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$25</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$30</th>
      </tr>
    </thead>
    <tbody>
    	<td style="text-align: center; vertical-align: middle;">
    		<figure class="image is-128x128 is-text-centered">
 					<img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png">
				</figure>
    	</td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
     
    </tbody>
  </table>

  <table id="redeem">
    <thead>
    	<tr>
    		<th> UNC Student Stores</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$5</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$10</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$15</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$20</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$25</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$30</th>
      </tr>
    </thead>
    <tbody>
    	<td style="text-align: center; vertical-align: middle;">
    		<figure class="image is-128x128 is-text-centered">
 					<img src="https://cs.unc.edu/files/2017/04/Student-Store-2017.png">
				</figure>
    	</td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
     
    </tbody>
  </table>
  
  <table id="redeem">
    <thead>
    	<tr>
    		<th> Insomnia Cookies</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$5</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$10</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$15</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$20</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$25</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$30</th>
      </tr>
    </thead>
    <tbody>
    	<td style="text-align: center; vertical-align: middle;">
    		<figure class="image is-128x128 is-text-centered">
 					<img src="https://cs.unc.edu/files/2017/04/InsomniaCookiesLogo.jpg">
				</figure>
    	</td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
     
    </tbody>
  </table>

  <table id="redeem">
    <thead>
    	<tr>
    		<th> Target </th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$5</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$10</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$15</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$20</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$25</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$30</th>
      </tr>
    </thead>
    <tbody>
    	<td style="text-align: center; vertical-align: middle;">
    		<figure class="image is-128x128 is-text-centered">
 					<img src="https://www.stickpng.com/assets/images/5842909da6515b1e0ad75abe.png">
				</figure>
    	</td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
     
    </tbody>
  </table>


  <table id="redeem">
    <thead>
    	<tr>
    		<th> Panera </th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$5</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$10</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$15</th>
      	<th style="text-align: center; vertical-align: middle; font-weight: bold;">$20</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$25</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold;">$30</th>
      </tr>
    </thead>
    <tbody>
    	<td style="text-align: center; vertical-align: middle;">
    		<figure class="image is-128x128 is-text-centered">
 					<img src="https://cs.unc.edu/files/2014/01/PaneraLogo.png">
				</figure>
    	</td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
      <td style="text-align: center; vertical-align: middle;"><button class="button is-medium">Redeem!</button></td>
     
    </tbody>
  </table>`;
}