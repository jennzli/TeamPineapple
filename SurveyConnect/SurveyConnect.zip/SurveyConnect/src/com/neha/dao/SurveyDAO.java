package com.neha.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.neha.bean.SurveyPO;
import com.survey.connect.util.DataBuilder;

public class SurveyDAO {
	
	public boolean addSurvey(SurveyPO po) {
		SurveyPO retPo = new SurveyPO();
		String insertSql="INSERT INTO SURVEY_CONTENT (NAME,DEPARTMENT,DESCRIPTION,RESTRICTION,URL_LINKS) VALUES (?,?,?,?,?)";
		MysqlConnection myConn = new MysqlConnection();
		Connection connection = null;
		try {
			connection = myConn.getConnection();
			PreparedStatement preparedStmt = connection.prepareStatement(insertSql);
			;
			preparedStmt.setString(1, po.getName());
			preparedStmt.setString(2, po.getDepartment());
			preparedStmt.setString(3, po.getDescription());
			preparedStmt.setString(4, po.getRestriction());
			preparedStmt.setString(5, po.getUrlLinks());
			
			preparedStmt.execute();
			
			connection.close();
			
			
	      return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
	 return false;
	}
	public List<SurveyPO> getSurveyDetails(SurveyPO po, String whereClause) {
		
		List<SurveyPO> poList = new ArrayList<SurveyPO>();
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		MysqlConnection myConn = new MysqlConnection();
		String selectSql=null;
		if(whereClause!=null) {
			selectSql= "SELECT ID,NAME,DEPARTMENT,DESCRIPTION,RESTRICTION,URL_LINKS FROM SURVEY_CONTENT "+whereClause;
		}else {
			selectSql= "SELECT ID,NAME,DEPARTMENT,DESCRIPTION,RESTRICTION,URL_LINKS FROM SURVEY_CONTENT";
		}try {
			connection = myConn.getConnection();
			System.out.println("SEARCH SELECT QUERY: ="+selectSql);
			statement = connection.createStatement();
			resultSet = statement.executeQuery(selectSql);
			poList=DataBuilder.buildSurveyData(resultSet, po);

		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return poList;
	}

}
